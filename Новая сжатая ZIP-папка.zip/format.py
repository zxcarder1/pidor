import json
from os import listdir, makedirs

default_dir = "./octo_sessions"

makedirs(default_dir, exist_ok=True)

files = listdir(default_dir)

for file in files:
    with open(f"{default_dir}/{file}", "r") as f:
        data = {
            data["name"]: data["value"]
            for data in json.loads(f.read())
            if data["domain"] == ".x.com"
        }

        with open(f"./sessions/{file}", "w", encoding="utf-8") as f:
            json.dump(data, f)