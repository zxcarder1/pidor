class Proxy:
    login: str
    password: str
    ip: str
    port: int

    def __init__(
        self,
        ip: str,
        port: int,
        login: str,
        password: str,
    ) -> None:
        self.login = login
        self.password = password
        self.ip = ip
        self.port = port


class Account:
    proxy: Proxy
    login: str
    password: str
    user_agent: str

    def __init__(
        self, proxy: Proxy, login: str, password: str, user_agent: str
    ) -> None:
        self.proxy = proxy
        self.login = login
        self.password = password
        self.user_agent = user_agent
